import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;
import java.lang.reflect.Method;

public class Main {
	public static void main(String[] args) throws Exception {
		AnalizadorListener listener = new AnalizadorListener();
		new ParseTreeWalker()
				.walk(listener,
						new snakeParser(new CommonTokenStream(new snakeLexer(
								new ANTLRInputStream(args.length > 0 ? new FileInputStream(args[0]) : System.in))))
										.prog());
		if (args.length > 1) {
			String filename = args[1];
			FileWriter fichero = new FileWriter("./" + filename);
			BufferedWriter bfwriter = new BufferedWriter(fichero);
			bfwriter.write(listener.getFile(args[0]));
			bfwriter.close();
			fichero.close();
		} else {
			System.out.print(listener.getFile());
		}
	}
}