// Generated from .\snakeParser.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link snakeParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface snakeParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link snakeParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(snakeParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncion(snakeParser.FuncionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControl(snakeParser.ControlContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#llamadafuncion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLlamadafuncion(snakeParser.LlamadafuncionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#declaracion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaracion(snakeParser.DeclaracionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#asignacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsignacion(snakeParser.AsignacionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#include}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInclude(snakeParser.IncludeContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#bloque}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBloque(snakeParser.BloqueContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#cuerpo_funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCuerpo_funcion(snakeParser.Cuerpo_funcionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#cuerpo_control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCuerpo_control(snakeParser.Cuerpo_controlContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#header_funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeader_funcion(snakeParser.Header_funcionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#header_control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeader_control(snakeParser.Header_controlContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#arg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArg(snakeParser.ArgContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(snakeParser.ExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#pr_funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_funcion(snakeParser.Pr_funcionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#pr_tipo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_tipo(snakeParser.Pr_tipoContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#pr_bloque}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_bloque(snakeParser.Pr_bloqueContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#pr_control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_control(snakeParser.Pr_controlContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#pr_include}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_include(snakeParser.Pr_includeContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#nombre_funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNombre_funcion(snakeParser.Nombre_funcionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#nombre_variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNombre_variable(snakeParser.Nombre_variableContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#nombre_libreria}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNombre_libreria(snakeParser.Nombre_libreriaContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#cadena}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCadena(snakeParser.CadenaContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#numero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumero(snakeParser.NumeroContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#flotante}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFlotante(snakeParser.FlotanteContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#tipo_devolucion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo_devolucion(snakeParser.Tipo_devolucionContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#basura}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBasura(snakeParser.BasuraContext ctx);
	/**
	 * Visit a parse tree produced by {@link snakeParser#parametros}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParametros(snakeParser.ParametrosContext ctx);
}