import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.*;

public class AnalizadorListener extends snakeParserBaseListener {

    private String file = "";
    private ArrayList<ParserRuleContext> recorrido = new ArrayList<>();

    private void add(String s) {
        file += s;
    }

    private void end() {
        file += "\n";
    }

    public String getFile(String fileName) {
        return file;
    }

    public String getFile() {
        return file;
    }

    @Override
    public void enterEveryRule(ParserRuleContext ctx) {

        recorrido.add(ctx);

        String entrada = "";
        boolean anadir = true;
        boolean salto = false;

        for (ParserRuleContext contexto : recorrido) {

            String cadena = snakeParser.ruleNames[contexto.getRuleIndex()];

            if (cadena != "basura") {
                entrada += "/" + cadena;
            } else { // No añadimos los nodos que tiene caracteres que no nos interesan
                anadir = false;
            }

            // Vemos si el siguiente sera termimal, para el caso en el que no lo sea
            // no hacer un salto de linea
            switch (cadena) {
            case "pr_include":
                salto = true;
                break;
            case "pr_funcion":
                salto = true;
                break;
            case "pr_tipo":
                salto = true;
                break;
            case "pr_bloque":
                salto = true;
                break;
            case "pr_control":
                salto = true;
                break;
            case "nombre_funcion":
                salto = true;
                break;
            case "nombre_variable":
                salto = true;
                break;
            case "nombre_libreria":
                salto = true;
                break;
            case "cadena":
                salto = true;
                break;
            case "flotante":
                salto = true;
                break;
            case "numero":
                salto = true;
                break;
            default:
                salto = false;
                break;
            }

        }

        if (anadir) { // Si no hay caracteres basura lo escribimos
            add(entrada);
            if (!salto) {
                end();
            }
        }

    }

    @Override
    public void exitEveryRule(ParserRuleContext ctx) {

        recorrido.remove(ctx);

    }

    @Override
    public void visitTerminal(TerminalNode node) {

        String caracter = node.getText();

        if (caracter.isEmpty()) {

        } else {
            switch (caracter) {
            case ":=":
                break;
            case "==":
                break;
            case "!=":
                break;
            case ">=":
                break;
            case "<=":
                break;
            case "<":
                break;
            case ">":
                break;
            case ",":
                break;
            case ";":
                break;
            case ":":
                break;
            case ")":
                break;
            case "(":
                break;
            case "+":
                break;
            case "-":
                break;
            case "*":
                break;
            case "/":
                break;
            default:
                add(":" + node.getText());
                end();
                break;
            }
        }
    }

    @Override
    public void visitErrorNode(ErrorNode node) {
        add(":error - ");
        file += node.getText();
        end();
    }
}