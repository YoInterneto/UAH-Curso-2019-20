// Generated from snakeParser.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link snakeParser}.
 */
public interface snakeParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link snakeParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(snakeParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(snakeParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#funcion}.
	 * @param ctx the parse tree
	 */
	void enterFuncion(snakeParser.FuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#funcion}.
	 * @param ctx the parse tree
	 */
	void exitFuncion(snakeParser.FuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#control}.
	 * @param ctx the parse tree
	 */
	void enterControl(snakeParser.ControlContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#control}.
	 * @param ctx the parse tree
	 */
	void exitControl(snakeParser.ControlContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#llamadafuncion}.
	 * @param ctx the parse tree
	 */
	void enterLlamadafuncion(snakeParser.LlamadafuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#llamadafuncion}.
	 * @param ctx the parse tree
	 */
	void exitLlamadafuncion(snakeParser.LlamadafuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracion(snakeParser.DeclaracionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracion(snakeParser.DeclaracionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion(snakeParser.AsignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion(snakeParser.AsignacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#include}.
	 * @param ctx the parse tree
	 */
	void enterInclude(snakeParser.IncludeContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#include}.
	 * @param ctx the parse tree
	 */
	void exitInclude(snakeParser.IncludeContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#bloque}.
	 * @param ctx the parse tree
	 */
	void enterBloque(snakeParser.BloqueContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#bloque}.
	 * @param ctx the parse tree
	 */
	void exitBloque(snakeParser.BloqueContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#cuerpo_funcion}.
	 * @param ctx the parse tree
	 */
	void enterCuerpo_funcion(snakeParser.Cuerpo_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#cuerpo_funcion}.
	 * @param ctx the parse tree
	 */
	void exitCuerpo_funcion(snakeParser.Cuerpo_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#cuerpo_control}.
	 * @param ctx the parse tree
	 */
	void enterCuerpo_control(snakeParser.Cuerpo_controlContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#cuerpo_control}.
	 * @param ctx the parse tree
	 */
	void exitCuerpo_control(snakeParser.Cuerpo_controlContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#header_funcion}.
	 * @param ctx the parse tree
	 */
	void enterHeader_funcion(snakeParser.Header_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#header_funcion}.
	 * @param ctx the parse tree
	 */
	void exitHeader_funcion(snakeParser.Header_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#header_control}.
	 * @param ctx the parse tree
	 */
	void enterHeader_control(snakeParser.Header_controlContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#header_control}.
	 * @param ctx the parse tree
	 */
	void exitHeader_control(snakeParser.Header_controlContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#arg}.
	 * @param ctx the parse tree
	 */
	void enterArg(snakeParser.ArgContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#arg}.
	 * @param ctx the parse tree
	 */
	void exitArg(snakeParser.ArgContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(snakeParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(snakeParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#pr_funcion}.
	 * @param ctx the parse tree
	 */
	void enterPr_funcion(snakeParser.Pr_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#pr_funcion}.
	 * @param ctx the parse tree
	 */
	void exitPr_funcion(snakeParser.Pr_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#pr_tipo}.
	 * @param ctx the parse tree
	 */
	void enterPr_tipo(snakeParser.Pr_tipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#pr_tipo}.
	 * @param ctx the parse tree
	 */
	void exitPr_tipo(snakeParser.Pr_tipoContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#pr_bloque}.
	 * @param ctx the parse tree
	 */
	void enterPr_bloque(snakeParser.Pr_bloqueContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#pr_bloque}.
	 * @param ctx the parse tree
	 */
	void exitPr_bloque(snakeParser.Pr_bloqueContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#pr_control}.
	 * @param ctx the parse tree
	 */
	void enterPr_control(snakeParser.Pr_controlContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#pr_control}.
	 * @param ctx the parse tree
	 */
	void exitPr_control(snakeParser.Pr_controlContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#pr_include}.
	 * @param ctx the parse tree
	 */
	void enterPr_include(snakeParser.Pr_includeContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#pr_include}.
	 * @param ctx the parse tree
	 */
	void exitPr_include(snakeParser.Pr_includeContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#nombre_funcion}.
	 * @param ctx the parse tree
	 */
	void enterNombre_funcion(snakeParser.Nombre_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#nombre_funcion}.
	 * @param ctx the parse tree
	 */
	void exitNombre_funcion(snakeParser.Nombre_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#nombre_variable}.
	 * @param ctx the parse tree
	 */
	void enterNombre_variable(snakeParser.Nombre_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#nombre_variable}.
	 * @param ctx the parse tree
	 */
	void exitNombre_variable(snakeParser.Nombre_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#nombre_libreria}.
	 * @param ctx the parse tree
	 */
	void enterNombre_libreria(snakeParser.Nombre_libreriaContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#nombre_libreria}.
	 * @param ctx the parse tree
	 */
	void exitNombre_libreria(snakeParser.Nombre_libreriaContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#cadena}.
	 * @param ctx the parse tree
	 */
	void enterCadena(snakeParser.CadenaContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#cadena}.
	 * @param ctx the parse tree
	 */
	void exitCadena(snakeParser.CadenaContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#numero}.
	 * @param ctx the parse tree
	 */
	void enterNumero(snakeParser.NumeroContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#numero}.
	 * @param ctx the parse tree
	 */
	void exitNumero(snakeParser.NumeroContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#flotante}.
	 * @param ctx the parse tree
	 */
	void enterFlotante(snakeParser.FlotanteContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#flotante}.
	 * @param ctx the parse tree
	 */
	void exitFlotante(snakeParser.FlotanteContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#tipo_devolucion}.
	 * @param ctx the parse tree
	 */
	void enterTipo_devolucion(snakeParser.Tipo_devolucionContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#tipo_devolucion}.
	 * @param ctx the parse tree
	 */
	void exitTipo_devolucion(snakeParser.Tipo_devolucionContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#basura}.
	 * @param ctx the parse tree
	 */
	void enterBasura(snakeParser.BasuraContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#basura}.
	 * @param ctx the parse tree
	 */
	void exitBasura(snakeParser.BasuraContext ctx);
	/**
	 * Enter a parse tree produced by {@link snakeParser#parametros}.
	 * @param ctx the parse tree
	 */
	void enterParametros(snakeParser.ParametrosContext ctx);
	/**
	 * Exit a parse tree produced by {@link snakeParser#parametros}.
	 * @param ctx the parse tree
	 */
	void exitParametros(snakeParser.ParametrosContext ctx);
}